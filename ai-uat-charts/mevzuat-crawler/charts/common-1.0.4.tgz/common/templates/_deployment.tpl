{{/*
deployement
{{ include "common.deployment" ( dict "deployment" .Values.path.to.the.deployment "context" $) }}
*/}}
{{- define "common.deployment" -}}
apiVersion: {{  include "common.capabilities.deployment.apiVersion" .context  }}   
kind: Deployment
metadata:
  name: {{ .deployment.name }}
  namespace: {{ .context.Release.Namespace | quote }}
  labels: {{- include "common.labels.standard" .context | nindent 4 }}
    {{- if .deployment.labels }}
    {{- tpl (toYaml .deployment.labels) .context | nindent 4 }}
    {{- end }}
  {{- if contains (lower "SNAPSHOT") (lower .context.Chart.AppVersion) }}
    {{- include "common.label.development" .context | nindent 4 }}
  {{- end }}
  {{- if .deployment.annotations }}
  annotations: 
    {{- tpl (toYaml .deployment.annotations) .context | nindent 4 }}
  {{- end }}
spec:
   {{- if not .deployment.autoscaling.enabled }}
  replicas: {{ required "replicaCount is required" .deployment.replicaCount }}
  {{- end }}
  selector:
    matchLabels: {{- include "common.labels.matchLabels" .context | nindent 6 }}
  {{- if .deployment.updateStrategy }}
  strategy: {{- tpl (toYaml .deployment.updateStrategy) .context | nindent 4 }}
  {{- end }}
  template:
    metadata:
      labels: {{- include "common.labels.standard" .context | nindent 8 }}
        {{- if .deployment.podLabels }}
        {{- include "common.tplvalues.render" (dict "value" .deployment.podLabels "context" .context) | nindent 8 }}
        {{- end }}
      {{- if .deployment.podAnnotations }}
      annotations: {{- include "common.tplvalues.render" (dict "value" .deployment.podAnnotations "context" .context) | nindent 8 }}
      {{- end }}
    spec: {{- include "common.pod.spec" (dict "spec" .deployment "context" .context) | nindent 6 }}
{{- end }}
