{{/*
{{ include "common.test-connection" ( dict "testConnection" .Values.path.to.the.test-connection "context" $) }}
*/}}
{{- define "common.test-connection" -}}
apiVersion: v1
kind: Pod
metadata:
  name: {{ .testConnection.name }}
  namespace: {{ .context.Release.Namespace | quote }}
  labels: {{- include "common.labels.standard" .context | nindent 4 }}
  annotations:
    "helm.sh/hook": test
spec:
  containers:
    - name: wget
      image: busybox
      command: ['wget']
      args: ['{{ .testConnection.host }}:{{ .testConnection.port }}']
  restartPolicy: Never
{{end}}
