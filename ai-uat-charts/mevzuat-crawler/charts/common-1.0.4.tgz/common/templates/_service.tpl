{{/*
Return service
{{ include "common.service" ( dict "service" .Values.path.to.the.service "context" $) }}
*/}}
{{- define "common.service" -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ .service.name }}
  namespace: {{ .context.Release.Namespace | quote }}
  labels: {{- include "common.labels.standard" .context | nindent 4 }}
    {{- if .service.labels }}
    {{- tpl (toYaml .service.labels) .context | nindent 4 }}
    {{- end }}
  {{- if .service.annotations }}
  annotations: 
    {{- tpl (toYaml .service.annotations) .context | nindent 4 }}
  {{- end }}
spec:
  selector: {{- include "common.labels.matchLabels" .context | nindent 6 }}
    {{- if .service.selector }}
    {{- tpl (toYaml .service.selector) .context | nindent 6 }}
    {{- end }}
  type: {{ .service.type }}
  ports:
  {{- include "common.tplvalues.render" (dict "value" .service.ports "context" .context) | nindent 2 }}
{{- end }}

