{{/*
istio destinationrule
{{ include "infra.istio.destinationrule" ( dict "destinationrule" .Values.path.to.the.istio.destinationrule "context" $) }}
*/}}
{{- define "infra.istio.destinationrule" -}}
{{- $context := .context }}
{{- range $d := .destinationrule }}
---
apiVersion: {{ include "common.capabilities.istio.apiVersion" $context }}
kind: DestinationRule
metadata:
  name: {{ $d.name }}
  namespace: {{ $context.Release.Namespace | quote }}
spec:
  host: {{ default $d.name $d.host }}
  {{- if $d.trafficPolicy }}
  trafficPolicy:
    {{-  (toYaml $d.trafficPolicy)  | nindent 4 }}
  {{- end }}
  {{- if $d.subsets }}
  subsets:
    {{-  (toYaml $d.subsets)  | nindent 2 }}
  {{- end }}
{{- end }}
{{- end }}


{{/*
istio gateway
{{ include "infra.istio.gateway" ( dict "gateway" .Values.path.to.the.istio.gateway "context" $) }}
*/}}
{{- define "infra.istio.gateway" -}}
{{- $context := .context }}
{{- range $g := .gateway }}
---
apiVersion: {{ include "common.capabilities.istio.apiVersion" $context }}
kind: Gateway
metadata:
  name: {{ $g.name }}
  namespace: {{ $context.Release.Namespace | quote }}
spec:
  selector:
    {{-  (toYaml $g.selector)  | nindent 4 }}
  servers:
    {{-  (toYaml $g.servers)  | nindent 4 }}
{{- end }}
{{- end }}

{{/*
istio serviceentry
{{ include "infra.istio.serviceentry" ( dict "serviceentry" .Values.path.to.the.istio.serviceentry "context" $) }}
*/}}
{{- define "infra.istio.serviceentry" -}}
{{- $context := .context }}
{{- range $se := .serviceentry }}
---
apiVersion: {{ include "common.capabilities.istio.apiVersion" $context }}
kind: ServiceEntry
metadata:
  name: {{ $se.name }}
  namespace: {{ $context.Release.Namespace | quote }}
spec:
  hosts: {{-  (toYaml $se.hosts)  | nindent 4 }}
  location: {{ $se.location }}
  ports:
    {{-  (toYaml $se.ports)  | nindent 4 }}
  resolution: {{ $se.resolution }}
{{- end }}
{{- end }}

{{/*
istio virtualservice
{{ include "infra.istio.virtualservice" ( dict "virtualservice" .Values.path.to.the.istio.virtualservice "context" $) }}
*/}}
{{- define "infra.istio.virtualservice" -}}
{{- $context := .context }}
{{- range $v := .virtualservice }}
---
apiVersion: {{ include "common.capabilities.istio.apiVersion" $context }}
kind: VirtualService
metadata:
  name: {{ $v.name }}
  namespace: {{ $context.Release.Namespace | quote }}
spec:
  {{- if $v.virtualservice }}
  hosts: {{-  (toYaml $v.virtualservice)  | nindent 4 }}
  {{- end }}
  {{- if $v.gateways }}
  gateways: {{-  (toYaml $v.gateways)  | nindent 4 }}
  {{- end }}
  {{- if $v.exportTo }}
  exportTo: {{-  (toYaml $v.exportTo)  | nindent 4 }}
  {{- end }}
  {{- if $v.http }}
  http: {{- (toYaml $v.http)  | nindent 4 }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Return the secret
{{ include "common.secret" ( dict "secret" .Values.path.to.the.secret "context" $) }}
*/}}
{{- define "infra.secret" -}}
{{- $context := .context }}
{{- range $s := .secret }}
---
apiVersion: v1
kind: Secret
metadata:
  name: {{ $s.name }}
  namespace: {{ $context.Release.Namespace | quote }}
  labels: {{- include "common.labels.standard" $context | nindent 4 }}
    {{- if $s.labels }}
    {{-  (toYaml $s.labels)  | nindent 4 }}
    {{- end }}
  {{- if $s.annotations }}
  annotations: 
    {{-  (toYaml $s.annotations)  | nindent 4 }}
  {{- end }}
type: Opaque
data:
  password: {{ $s.password | b64enc | quote }}
{{- end }}
{{- end }}

{{/*
Return service
{{ include "common.configmap" ( dict "service" .Values.path.to.the.configmap "context" $) }}
*/}}
{{- define "infra.configmap" -}}
{{- $context := .context }}
{{- range $c := .configmap}}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $c.name }}
  namespace: {{ $context.Release.Namespace}}
  labels: {{- include "common.labels.standard" $context | nindent 4 }}
    {{- if $c.labels }}
    {{-  (toYaml $c.labels)  | nindent 4 }}
    {{- end }}
  {{- if $c.annotations }}
  annotations: 
    {{- (toYaml $c.annotations)  | nindent 4 }}
  {{- end }}
data:
  {{- (toYaml $c.data)  | nindent 4 }}
{{- end }}
{{- end }}
{{/*
Return service
{{ include "infra.PersistentVolume" ( dict "PersistentVolume" .Values.path.to.the.PersistentVolume "context" $) }}
*/}}
{{- define "infra.PersistentVolume" -}}
{{- $context := .context }}
{{- range $p := .PersistentVolume}}
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: {{ $p.name }}
  namespace: {{ $context.Release.Namespace}}
spec:
  {{- if $p.capacity }}
  capacity: 
    {{-  (toYaml $p.capacity)  | nindent 4 }}
  {{- end }}
  {{- if $p.capacity }}
  accessModes: 
    {{-  (toYaml $p.accessModes)  | nindent 4 }}
  {{- end }}
  {{- if $p.storageClassName }}
  storageClassName: {{ $p.storageClassName }}
  {{- end }}
  {{- if $p.nfs }}
  nfs: 
    {{-  (toYaml $p.nfs)  | nindent 4 }}
  {{- end }}
  {{- if $p.mountOptions }}
  mountOptions: 
    {{-  (toYaml $p.mountOptions)  | nindent 4 }}
  {{- end }}
  {{- if $p.persistentVolumeReclaimPolicy }}
  persistentVolumeReclaimPolicy: {{ $p.persistentVolumeReclaimPolicy}}
  {{- end }}
  {{- end }}
  {{- end }}

{{/*
Return service
{{ include "infra.PersistentVolumeClaim" ( dict "PersistentVolumeClaim" .Values.path.to.the.PersistentVolumeClaim "context" $) }}
*/}}
{{- define "infra.PersistentVolumeClaim" -}}
{{- $context := .context }}
{{- range $pvc := .PersistentVolumeClaim}}
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: {{ $pvc.name}}
  namespace: {{ $context.Release.Namespace}}
spec:
  {{- if $pvc.accessModes }}
  accessModes: 
    {{-  (toYaml $pvc.accessModes)  | nindent 4 }}
  {{- end }}
  {{- if $pvc.storageClassName }}
  storageClassName: {{$pvc.storageClassName}}
  {{- end }}
  {{- if $pvc.resources }}
  resources:
    {{-  (toYaml $pvc.resources)  | nindent 4 }}
  {{- end }}
  {{- if $pvc.volumeName }}
  volumeName: {{ $pvc.volumeName}}
  {{- end }}
  {{- end }}
  {{- end }}
