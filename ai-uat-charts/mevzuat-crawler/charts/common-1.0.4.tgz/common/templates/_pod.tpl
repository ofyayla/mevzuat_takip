{{/*
Pod Spec
{{ include "common.pod.spec" ( dict "spec" .Values.path.to.the.deployment.spec "context" $) }}
*/}}
{{- define "common.pod.spec" -}}
containers:
- name: {{ .spec.name }}
  image: {{ include "common.images.image" ( dict "imageRoot" .spec.image "context" $) }}
  {{- if .spec.command }}
  {{- if .spec.command.key }}
  command: {{ include "common.tplvalues.render" (dict "value" .spec.command.key "context" .context) }}
  {{- end }}
  {{- if .spec.command.args }}
  args: 
  {{- include "common.tplvalues.render" (dict "value" .spec.command.args "context" .context) | nindent 2 }}
  {{- end }}
  {{- end }}
  imagePullPolicy: {{ .spec.image.pullPolicy | quote }}
  {{- if .spec.envVars }}
  env:
  {{- include "common.tplvalues.render" (dict "value" .spec.envVars "context" .context) | nindent 2 }}
  {{- end }}
  {{- if .spec.resources }}
  resources:
  {{- include "common.tplvalues.render" (dict "value" .spec.resources "context" .context) | nindent 4 }}
  {{- end }}
  {{- if or .spec.envVarsCM .spec.envVarsSecret }}
  envFrom:
  {{- if .spec.envVarsCM }}
  - configMapRef:
      name: {{ include "common.tplvalues.render" (dict "value" .spec.envVarsCM "context" .context) }}
  {{- end }}
  {{- if .spec.envVarsSecret }}
  - secretRef:
      name: {{ include "common.tplvalues.render" (dict "value" .spec.envVarsSecret "context" .context) }}
  {{- end }}
  {{- end }}
  ports:
  - name: http-api
    containerPort: {{required "at least one containerPort is required" .spec.containerPort }}
  {{- if .spec.containerExtraPorts }}
  {{- include "common.tplvalues.render" (dict "value" .spec.containerExtraPorts "context" .context) | nindent 2 }}
  {{- end }}
  {{- if .spec.lifecycle }}
  lifecycle:
  {{- include "common.tplvalues.render" (dict "value" .spec.lifecycle "context" .context) | nindent 4 }}  
  {{- end }}
  {{- if .spec.livenessProbe }}
  livenessProbe:
  {{- include "common.tplvalues.render" (dict "value" .spec.livenessProbe "context" .context) | nindent 4 }}  
  {{- end }}
  {{- if .spec.readinessProbe }}
  readinessProbe:
  {{- include "common.tplvalues.render" (dict "value" .spec.readinessProbe "context" .context) | nindent 4 }}  
  {{- end }}
  {{- if .spec.startupProbe }}
  startupProbe:
  {{- include "common.tplvalues.render" (dict "value" .spec.startupProbe "context" .context) | nindent 4 }}    
  {{- end }}
  {{- if .spec.volumeMounts }}
  volumeMounts:
  {{- include "common.tplvalues.render" (dict "value" .spec.volumeMounts "context" .context) | nindent 2 }}
  {{- end }}
{{- if .spec.volumes }}
volumes:
{{ include "common.tplvalues.render" (dict "value" .spec.volumes "context" .context) }}
{{- end }}
{{- if .spec.image.pullSecrets }}
imagePullSecrets:
  {{- range .spec.image.pullSecrets }}
- name:  {{ . }}
  {{- end }}
{{- end }}
{{- end -}}
